# Coffee Shop Theme - Thème Artisanal pour GrandNode

Un thème chaleureux et authentique conçu pour les boutiques de café en ligne.

## Caractéristiques

### Design Artisanal & Authentique
- **Palette de couleurs chaudes** inspirée des grains de café torréfiés
- **Typographie soignée** avec des polices Handwritten (Caveat) et Serif (Merriweather, Playfair Display)
- **Textures subtiles** rappelant le papier kraft et les sacs de café en toile de jute
- **Animations douces** avec des grains de café flottants

### Fonctionnalités
- ✅ Responsive design (mobile, tablet, desktop)
- ✅ Hero section impressionnant avec call-to-action
- ✅ Sections de produits avec effet hover élégant
- ✅ Page produit détaillée avec galerie d'images
- ✅ Filtres latéraux pour le catalog
- ✅ Vue grille et vue liste pour les produits
- ✅ Menu navigation sticky
- ✅ Intégration complète avec GrandNode

## Installation

### 1. Build du thème

```bash
cd /home/user/projects/dev/grandnode2
dotnet build src/Plugins/Theme.CoffeeShop/Theme.CoffeeShop.csproj -c Debug
```

### 2. Vérifier le déploiement

Le thème sera automatiquement copié dans :
```
src/Web/Grand.Web/Plugins/Theme.CoffeeShop/
```

### 3. Activer le thème

1. Démarrer GrandNode
2. Aller dans **Admin > Configuration > Themes**
3. Sélectionner **"Coffee Shop - Artisanal Theme"**
4. Cliquer sur **"Apply theme"**

## Palette de Couleurs

```css
--coffee-dark: #3E2723      /* Dark roasted coffee */
--coffee-medium: #6D4C41    /* Medium roast */
--coffee-light: #A1887F     /* Light roast */
--cream: #F5E6D3            /* Cream */
--latte: #EDD5B8            /* Latte foam */
--espresso: #2C1810         /* Deep espresso */
--parchment: #FDF6EC        /* Old parchment */
--burlap: #C8B098           /* Coffee sack burlap */
--accent-gold: #D4AF37      /* Golden hour */
--accent-green: #556B2F     /* Coffee plant leaves */
```

## Typographie

- **Handwritten**: Caveat (titres expressifs, citations)
- **Serif**: Merriweather (corps de texte, lisibilité)
- **Display**: Playfair Display (titres principaux, élégance)

## Structure des fichiers

```
Theme.CoffeeShop/
├── Content/
│   ├── css/
│   │   ├── common/common.css       # Styles globaux
│   │   ├── header/header.css       # En-tête et navigation
│   │   ├── home/home.css           # Page d'accueil
│   │   ├── product/product.css     # Page produit
│   │   └── catalog/catalog.css     # Page catalogue
│   ├── script/
│   │   └── app.js                  # JavaScript principal
│   ├── images/                     # Images et SVG
│   └── theme.jpg                   # Preview du thème
├── Views/CoffeeShop/
│   ├── Shared/
│   │   ├── _Layout.cshtml          # Layout principal
│   │   └── Head.cshtml             # Ressources CSS/JS
│   └── Home/
│       └── Index.cshtml            # Page d'accueil
└── README.md
```

## Customisation

### Modifier les couleurs

Éditer les variables CSS dans `Content/css/common/common.css` :

```css
:root {
    --coffee-dark: #votrecouleur;
    --accent-gold: #votreaccent;
    /* ... */
}
```

### Changer les polices

Modifier dans `Views/CoffeeShop/Shared/Head.cshtml` :

```html
<link href="https://fonts.googleapis.com/css2?family=VotrePolice&display=swap" rel="stylesheet">
```

Puis dans `common.css` :

```css
:root {
    --font-handwritten: 'VotrePolice', cursive;
}
```

### Personnaliser le hero

Éditer `Views/CoffeeShop/Home/Index.cshtml`, section `.hero-content`.

## Compatibilité

- **GrandNode**: 2.3.0+
- **ASP.NET Core**: 9.0
- **Browsers**: Chrome, Firefox, Safari, Edge (dernières versions)
- **Mobile**: iOS, Android

## Support

Pour toute question ou problème :
1. Vérifier que GrandNode 2.3.0+ est installé
2. Vérifier les logs dans le panneau admin
3. Rebuild le projet si les CSS ne se chargent pas

## Licence

Ce thème est fourni tel quel pour GrandNode.

## Crédits

- **Polices**: Google Fonts (Caveat, Merriweather, Playfair Display)
- **Icons**: Emojis Unicode
- **Framework**: Bootstrap Vue

---

**Fait avec ❤️ et beaucoup de café**
