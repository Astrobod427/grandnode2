using Grand.Infrastructure.Plugins;

[assembly: PluginInfo(
    FriendlyName = "Coffee Shop Theme - Artisanal & Authentic",
    Group = "Themes",
    SystemName = "Theme.CoffeeShop",
    Author = "GrandNode",
    Version = "1.0.0"
)]
