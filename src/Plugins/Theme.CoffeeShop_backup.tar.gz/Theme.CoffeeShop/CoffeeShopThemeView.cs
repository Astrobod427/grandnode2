using Grand.Web.Common.Themes;

namespace Theme.CoffeeShop;

public class CoffeeShopThemeView : IThemeView
{
    public string AreaName => "";
    public string ThemeName => "CoffeeShop";

    public ThemeInfo ThemeInfo => new(
        Title: "Coffee Shop - Artisanal Theme",
        PreviewImageUrl: "~/Plugins/Theme.CoffeeShop/Content/theme.jpg",
        PreviewText: "Un thème chaleureux et artisanal pour votre boutique de café. Design authentique avec des tonalités chaudes rappelant les grains de café torréfiés.",
        SupportRtl: false
    );

    public IEnumerable<string> GetViewLocations()
    {
        return new List<string> {
            "/Views/CoffeeShop/{1}/{0}.cshtml",
            "/Views/CoffeeShop/Shared/{0}.cshtml",
            "/Views/{1}/{0}.cshtml",
            "/Views/Shared/{0}.cshtml"
        };
    }
}
