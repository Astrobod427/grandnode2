using Grand.Infrastructure.Plugins;

namespace Theme.CoffeeShop;

public class CoffeeShopThemePlugin : BasePlugin, IPlugin
{
    public override string ConfigurationUrl()
    {
        return string.Empty;
    }
}
