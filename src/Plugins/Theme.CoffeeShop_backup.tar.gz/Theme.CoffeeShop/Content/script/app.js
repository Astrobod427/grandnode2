/* Coffee Shop Theme - Main JavaScript */

(function() {
    'use strict';

    // Mobile Menu Toggle
    function initMobileMenu() {
        const menuToggle = document.querySelector('.menu-toggle');
        const mainMenu = document.querySelector('.main-menu');

        if (menuToggle && mainMenu) {
            menuToggle.addEventListener('click', function() {
                mainMenu.classList.toggle('open');
                this.classList.toggle('active');
            });
        }
    }

    // Smooth Scroll
    function initSmoothScroll() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                const href = this.getAttribute('href');
                if (href !== '#') {
                    e.preventDefault();
                    const target = document.querySelector(href);
                    if (target) {
                        target.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                }
            });
        });
    }

    // Product Image Gallery
    function initProductGallery() {
        const thumbnails = document.querySelectorAll('.product-thumbnail');
        const mainImage = document.querySelector('.product-main-image img');

        thumbnails.forEach(thumb => {
            thumb.addEventListener('click', function() {
                const newSrc = this.querySelector('img').src;
                if (mainImage) {
                    mainImage.src = newSrc;
                }

                thumbnails.forEach(t => t.classList.remove('active'));
                this.classList.add('active');
            });
        });
    }

    // Product Tabs
    function initProductTabs() {
        const tabButtons = document.querySelectorAll('.tab-button');
        const tabContents = document.querySelectorAll('.tab-pane');

        tabButtons.forEach(button => {
            button.addEventListener('click', function() {
                const targetTab = this.dataset.tab;

                tabButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');

                tabContents.forEach(content => {
                    if (content.id === targetTab) {
                        content.style.display = 'block';
                    } else {
                        content.style.display = 'none';
                    }
                });
            });
        });
    }

    // Quantity Selector
    function initQuantitySelector() {
        const minusButtons = document.querySelectorAll('.quantity-btn.minus');
        const plusButtons = document.querySelectorAll('.quantity-btn.plus');

        minusButtons.forEach(btn => {
            btn.addEventListener('click', function() {
                const input = this.nextElementSibling;
                const currentValue = parseInt(input.value) || 1;
                if (currentValue > 1) {
                    input.value = currentValue - 1;
                }
            });
        });

        plusButtons.forEach(btn => {
            btn.addEventListener('click', function() {
                const input = this.previousElementSibling;
                const currentValue = parseInt(input.value) || 1;
                input.value = currentValue + 1;
            });
        });
    }

    // Mobile Filters Toggle
    function initMobileFilters() {
        const filterToggle = document.querySelector('.mobile-filters-toggle');
        const filtersSidebar = document.querySelector('.filters-sidebar');
        const filtersOverlay = document.querySelector('.filters-overlay');

        if (filterToggle && filtersSidebar) {
            filterToggle.addEventListener('click', function() {
                filtersSidebar.classList.toggle('open');
                if (filtersOverlay) {
                    filtersOverlay.classList.toggle('show');
                }
            });

            if (filtersOverlay) {
                filtersOverlay.addEventListener('click', function() {
                    filtersSidebar.classList.remove('open');
                    this.classList.remove('show');
                });
            }
        }
    }

    // View Mode Toggle
    function initViewMode() {
        const viewButtons = document.querySelectorAll('.view-btn');
        const productsGrid = document.querySelector('.catalog-products-grid');

        viewButtons.forEach(btn => {
            btn.addEventListener('click', function() {
                const viewMode = this.dataset.view;

                viewButtons.forEach(b => b.classList.remove('active'));
                this.classList.add('active');

                if (productsGrid) {
                    if (viewMode === 'list') {
                        productsGrid.classList.add('list-view');
                    } else {
                        productsGrid.classList.remove('list-view');
                    }
                }
            });
        });
    }

    // Add to Cart Animation
    function initAddToCartAnimation() {
        const addToCartButtons = document.querySelectorAll('.btn-add-to-cart, .add-to-cart-btn');

        addToCartButtons.forEach(btn => {
            btn.addEventListener('click', function() {
                const originalText = this.innerHTML;
                this.innerHTML = '<span>✓ Ajouté !</span>';
                this.style.background = 'var(--accent-green)';

                setTimeout(() => {
                    this.innerHTML = originalText;
                    this.style.background = '';
                }, 2000);
            });
        });
    }

    // Initialize on DOM ready
    document.addEventListener('DOMContentLoaded', function() {
        initMobileMenu();
        initSmoothScroll();
        initProductGallery();
        initProductTabs();
        initQuantitySelector();
        initMobileFilters();
        initViewMode();
        initAddToCartAnimation();

        console.log('☕ Coffee Shop Theme loaded successfully');
    });

})();
