using Grand.Infrastructure;
using Grand.Web.Common.Themes;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Theme.CoffeeShop;

public class StartupApplication : IStartupApplication
{
    public void ConfigureServices(IServiceCollection services, IConfiguration configuration)
    {
        Console.WriteLine("🔥🔥🔥 COFFEESHOP: ConfigureServices CALLED 🔥🔥🔥");
        services.AddScoped<IThemeView, CoffeeShopThemeView>();
        Console.WriteLine($"🔥🔥🔥 COFFEESHOP: IThemeView registered. Service count: {services.Count} 🔥🔥🔥");
    }

    public int Priority => 10;
    public bool BeforeConfigure => false;

    public void Configure(WebApplication application, IWebHostEnvironment webHostEnvironment)
    {
        Console.WriteLine("🔥🔥🔥 COFFEESHOP: Configure CALLED 🔥🔥🔥");
    }
}
